package practicepart2project7;

import java.io.FileWriter;
import java.io.IOException;

public class update {
    public static void main(String[] args) {
        // Update a file using FileWriter
        try {
            FileWriter writer = new FileWriter("example", true); 
            writer.write(" to update the file.");
            writer.close();
            System.out.println("File updated successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
