package practicepart2project6;

public class StringConstantPool {

	public static final String OUTPUT_SUCCESS="yes the amount is available ";
	public static final String FAILED="invalid balance";


}
