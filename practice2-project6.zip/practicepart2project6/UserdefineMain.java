package practicepart2project6;

	public class UserdefineMain {
		public static void main(String[] args) throws Invalidbankbalance {

			bankbalancevaldiator bankobj=new bankbalancevaldiator();
			bankobj.balancevalidator(100000);
			
		}
	}


