package practicepart2project6;

public class bankbalancevaldiator {
	public void balancevalidator(int balance) throws Invalidbankbalance {
		if (balance>20000) {
			System.out.println(StringConstantPool.OUTPUT_SUCCESS);
			System.out.println(balance-20000);
		}
		else {
			throw new Invalidbankbalance(StringConstantPool.FAILED);
		}
	}

}
