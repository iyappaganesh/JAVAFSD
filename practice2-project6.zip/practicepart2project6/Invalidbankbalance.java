package practicepart2project6;

public class Invalidbankbalance extends Exception {
	public Invalidbankbalance(String msg) {
		super(msg);
	}
	

}
