package com.ecommerce.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.ecommerce.pojo.EProduct;


public class EProductDAO {

	private JdbcTemplate temp;
	public void setTemp(JdbcTemplate temp) {
		this.temp = temp;
	}
	
	public List<EProduct> getProducts(){
		return temp.query("select * from eproduct",new ResultSetExtractor<List<EProduct>>() {

			@Override
			public List<EProduct> extractData(ResultSet rs) throws SQLException, DataAccessException {
				// TODO Auto-generated method stub
				List<EProduct> list=new ArrayList<>();
				while(rs.next()) {
					EProduct student=new EProduct();
					student.setName(rs.getString(2));
					student.setPrice(rs.getBigDecimal(3));
					student.setDateAdded(rs.getDate(4));
					list.add(student);
				}
				return list;
				
			}
		});

	}
}
