package com.ecommerce.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ecommerce.pojo.EProduct;

public class ProductMapper implements RowMapper<EProduct> {

	@Override
	public EProduct mapRow(ResultSet rs, int rowNum) throws SQLException {
		EProduct student=new EProduct();
		student.setName(rs.getString(2));
		student.setPrice(rs.getBigDecimal(3));
		student.setDateAdded(rs.getDate(4));
		return student;
	}

}
