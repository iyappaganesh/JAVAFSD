package com.ecommerce.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;

import com.ecommerce.dao.EProductDAO;
import com.ecommerce.pojo.EProduct;

@Controller
public class MainController {
	ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
	EProduct s=ac.getBean(EProduct.class);
	EProductDAO dao=ac.getBean(EProductDAO.class);
     public List<EProduct> listProducts()
     {
             List<EProduct> list= dao.getProducts();
             for(EProduct product: list) {
            	 System.out.println(product.getName());
             }
         return list;
     }


}
