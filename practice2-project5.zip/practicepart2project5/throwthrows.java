package practicepart2project5;
 class StringConstantPool {

		public static final String OUTPUT_SUCCESS="right to vote ";
		public static final String FAILED="the age is not fit for having a vote";
		
	}


class InvalidAgeException extends Exception{
		public InvalidAgeException(String msg) {
			super(msg);
		}

		
	}


 class AgeValidator {

		public void ageValidation(int age) throws InvalidAgeException {
			if(age>=18) {
				System.out.println(StringConstantPool.OUTPUT_SUCCESS);
			}
			else {
				throw new InvalidAgeException(StringConstantPool.FAILED);
			}
		}
		
	}



	public class throwthrows {
		public static void main(String[] args) throws InvalidAgeException {

			AgeValidator ageobj=new AgeValidator();
			ageobj.ageValidation(4);
			
		}
	}


