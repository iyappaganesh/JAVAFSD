package practiceproject9;

public class arrayTypes {
		public static void main(String[] args) {

		//single dimensional array
		int a[]= {1,2,3,4,5};
		for(int i=0;i<5;i++) {
		System.out.println("Elements of array a: "+a[i]);
		}
		String[] names = {"Alice", "Bob", "Charlie", "David"};//this is an array of strings
		for (String name : names) {
            System.out.println(name);
		}

		//multidimensional array
		int[][] b = {
		            {2, 4, 6, 8,1}, 
		            {3, 6, 9,7} };
		      
		      System.out.println("\nLength of row 1: " + b[0].length);
		      }
		}



