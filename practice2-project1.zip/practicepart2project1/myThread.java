package practicepart2project1;

public class myThread extends Thread {
	public void run()
	{
		System.out.println("thread is working");
	}
	public static void main( String args[] )
	{
		myThread threadObj = new myThread();
		threadObj.start();
	}
}



