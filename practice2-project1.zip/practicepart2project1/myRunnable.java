package practicepart2project1;
	class MyRunnable1 implements Runnable {
	    public void run() {
	        for (int i = 1; i <= 5; i++) {
	            System.out.println("Thread " + Thread.currentThread().getId() + " is running: " + i);
	        }
	    }
	}

	public class myRunnable {
	    public static void main(String[] args) {
	    	MyRunnable1 myRunnable = new MyRunnable1();
	        
	        Thread thread1 = new Thread(myRunnable);
	        Thread thread2 = new Thread(myRunnable);
	        
	        thread1.start();
	        thread2.start();
	    }
	}



