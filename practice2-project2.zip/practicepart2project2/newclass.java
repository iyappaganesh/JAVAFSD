package practicepart2project2;

public class newclass {
    public static void main(String[] args) {
        final Object lock = new Object();

        // Sleep
        Thread thread1 = new Thread(new Runnable() {
            public void run() {
                synchronized (lock) {
                    System.out.println("Thread 1 will sleep for 3 seconds.");
                    try {
                        Thread.sleep(3000); // Sleep for 3 seconds
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println("Thread 1 has woken up after sleeping.");
                }
            }
        });

        //  Wait
        Thread thread2 = new Thread(new Runnable() {
            public void run() {
                synchronized (lock) {
                    System.out.println("Thread 2 will wait for a signal.");
                    try {
                        lock.wait(); 
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println("Thread 2 has been notified and is continuing.");
                }
            }
        });

        // Start both threads
        thread1.start();
        thread2.start();

        // Sleep to ensure thread 1 executes first
        try {
            Thread.sleep(1000); // Sleep for 1 second
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Notify thread 2 to wake it up
        synchronized (lock) {
            lock.notify();
        }
    }
}
