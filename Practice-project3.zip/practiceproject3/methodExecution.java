package practiceproject3;
	class methodExecution1 {
	double incrSalary(double salary,double bonus) {
		return bonus+salary;
	}
	
}


public class methodExecution {

	public static void main(String[] args) {
		methodExecution1 methodExecution1=new methodExecution1();
		double finalamount=methodExecution1.incrSalary(50000, 4000);
		System.out.println("final salary is -->"+finalamount);
	}

}





