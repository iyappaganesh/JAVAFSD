package practiceproject3;

 	class overloadMethod1 {
		double salary,bonus;
		void incrSalary() {
			double finalamount=bonus+salary;
			System.out.println("final salary is -->"+finalamount);
		}

	}


public class overloadMethod {

		public static void main(String[] args) {
			overloadMethod1 overloadMethod1=new overloadMethod1();
			overloadMethod1.bonus=4000;
			overloadMethod1.salary=50000;
			overloadMethod1.incrSalary();
			
		}

	}




