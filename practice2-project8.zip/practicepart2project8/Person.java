package practicepart2project8;

public class Person {  	        //encapsulation
	
private	int perId;
private	String perName;
private String perEmail;   
public int getPerId() {
	return perId;
}
public String getPerName() {
	return perName;
}
public void setPerId(int perId) {
	this.perId = perId;
}
public void setPerName(String perName) {
	this.perName = perName;
}
public void setPerEmail(String perEmail) {
	this.perEmail = perEmail;
}
public String getPerEmail() {
	return perEmail;
}




		
}
