package practicepart2project8;
class parentBank{                             //inheritance
	double roi;
	double amount;
}

class hdfc extends parentBank{
	void calculateamountWithRoi(double amount,double roi){
		System.out.println(amount + amount*roi);
	}
}
class icici extends hdfc{
	void calculateamountWithRoi1(double amount,double roi){
		System.out.println(amount + amount*roi);
	}
}
	

public class bank {
	public static void main(String[] args) {
		hdfc hdfcObj = new hdfc();
		hdfcObj.calculateamountWithRoi(100,7.5);
		
		icici iciciObj = new icici();
		iciciObj.calculateamountWithRoi1(200, 8.5);
	}

}

