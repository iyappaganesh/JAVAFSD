package practicepart2project8;

 class amount {  	
	 amount() {
		double salary=50000;
		double bonus=4000;
		double finalamount=bonus+salary;
		System.out.println("final salary is -->"+finalamount);
	}

}


public class ClassObject {

	public static void main(String[] args) {
		amount amountobj=new amount();
		
	}

}

