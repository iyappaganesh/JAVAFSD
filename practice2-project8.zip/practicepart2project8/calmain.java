package practicepart2project8;

 abstract class Calculator {                  // abstraction

	public abstract void sum(int value1 , int value2);
	public abstract void sub(int value1 , int value2);
	
}
 class CalculatorImpl extends Calculator {

	@Override
	public void sum(int value1, int value2) {
		System.out.println("sum of the numbers are :"+(value1+value2));
		
	}

	@Override
	public void sub(int value1, int value2) {
		// TODO Auto-generated method stub
		System.out.println("sub of the numbers are :"+(value1-value2));
	}

}


public class calmain {

	public static void main(String[] args) {
		CalculatorImpl calimpl=new CalculatorImpl();
		calimpl.sub(23,34);
	}

}
