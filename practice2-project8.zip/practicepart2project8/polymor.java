package practicepart2project8;     
class polymorphism {
		void primitivePreference() {
			System.out.println("no args");    //this is a polymorphism example
		}

		void primitivePreference(int a) {
			System.out.println("int type ");
		}

		void primitivePreference(byte a) {
			System.out.println("double args");
		}
		void primitivePreference(short a) {
			System.out.println("no args");
		}
		void primitivePreference(long a) {
			System.out.println("no args");
		}
		void primitivePreference(float a) {
			System.out.println("no args");
		}
		void primitivePreference(double a) {
			System.out.println("no args");
		}
		void primitivePreference(boolean a) {
			System.out.println("no args");
}
}

public class polymor {
	public static void main(String[] args) {
		polymorphism polyObj = new polymorphism();
		polyObj.primitivePreference(2);
	}
	
	
	
}
