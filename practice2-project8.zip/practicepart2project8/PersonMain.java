package practicepart2project8;

public class PersonMain {       //encapsulation

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person person1=new Person();
		person1.setPerId(1);
		person1.setPerName("iyappa");
		person1.setPerEmail("y@c.c");
		System.out.println(person1.getPerId()+"  "+person1.getPerName()+"  "+person1.getPerEmail());
		}

	}



