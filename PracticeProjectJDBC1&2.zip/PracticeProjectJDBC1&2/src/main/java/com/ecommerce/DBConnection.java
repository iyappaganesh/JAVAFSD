package com.ecommerce;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    
	public static Connection dbConn() throws ClassNotFoundException, SQLException {
		//Register the driver 
		Class.forName(DbConstantPool.DRIVER_CLASS);

		//connection with the dB 
		Connection conn=DriverManager.getConnection(DbConstantPool.DB_URL,DbConstantPool.USERNAME,DbConstantPool.PASSWORD);
		return conn;
	}

	public static void closeConnection(Connection conn) throws SQLException {
		if (conn != null)
			conn.close();
	}

}
