package practiceproject7;

public class innerClassA2 {

private String msg="Inner Classes";

 void display(){  
	 class Inner{  
		 void msg(){
			 System.out.println(msg);
		 }  
  }  
  
  Inner l=new Inner();  
  l.msg();  
 }  

 
public static void main(String[] args) {
	innerClassA2  innerClassA2obj =new innerClassA2 ();  
	innerClassA2obj.display();  
	}
}

