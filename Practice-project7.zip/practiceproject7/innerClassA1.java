package practiceproject7;

public class innerClassA1 {
	private String msg="hi"; 
	 
	 class Inner{  
	  void hello(){System.out.println(msg+", this is Inner Classes");}  
	 }  


	public static void main(String[] args) {

		innerClassA1 innerClassA1obj=new innerClassA1();
		innerClassA1.Inner in=innerClassA1obj.new Inner();  
		in.hello();  
	}


}
