package practiceproj;

public class typeconversionpractice {
	public static void main(String[] args) {
		int a = 20;
		byte b = (byte)a;    // explicit  type casting 
		int c = b;           // implicit type casting
		System.out.println(b);
		System.out.println(c);
	}
	
}
