package practiceproject8;

public class typesOfString {
		public static void main(String[] args) {
			//methods of strings
			System.out.println("Methods of Strings");
			//finding length
			String sl=new String("length");
			System.out.println(sl.length());

			//substring method
			String sub=new String("Welcome");
			System.out.println(sub.substring(2));

			//Comparison method
			String s1="Hello";
			String s2="Heldo";
			System.out.println(s1.compareTo(s2));

			//IsEmpty method
			String s4="";
			System.out.println(s4.isEmpty());

			//toLowerCase method
			String s5="LOWER";
			System.out.println(s1.toLowerCase());
			
			//replace method
			String s6="dambda";
			String replace=s2.replace('d', 'l');
			System.out.println(replace);

			//equals method
			String x="Welcome to Java";
			String y="WeLcOmE tO JaVa";
			System.out.println(x.equals(y));
	 
			System.out.println("\n");
			System.out.println("working with StringBuffer");
			//Creating StringBuffer and append method
			StringBuffer s=new StringBuffer("Welcome to Java!");
			s.append("appended paragraph");
			System.out.println(s);

			//insert method
			s.insert(0, 'w');
			System.out.println(s);

			//replace method
			StringBuffer sb=new StringBuffer("Hello");
			sb.replace(0, 2, "hEl");
			System.out.println(sb);

			//delete method
			sb.delete(0, 1);
			System.out.println(sb);
			
			//StringBuilder
			System.out.println("\n");
			System.out.println("Creating StringBuilder");
			StringBuilder sb1=new StringBuilder("Happy");
			sb1.append("Learning");
			System.out.println(sb1);

			System.out.println(sb1.delete(0, 1));

			System.out.println(sb1.insert(1, "Welcome"));

			System.out.println(sb1.reverse());
					
			//conversion	
			System.out.println("\n");
			System.out.println("Conversion of Strings to StringBuffer and StringBuilder");
			
			String str = "Hello"; 
	        
	        // conversion from String object to StringBuffer 
	        StringBuffer StringBuffersbr = new StringBuffer(str); 
	        StringBuffersbr.reverse(); 
	        System.out.println("String to StringBuffer");
	        System.out.println(StringBuffersbr); 
	          
	        // conversion from String object to StringBuilder 
	        StringBuilder StringBuildersbl = new StringBuilder(str); 
	        StringBuildersbl.append("world"); 
	        System.out.println("String to StringBuilder");
	        System.out.println(StringBuildersbl);              		
		}
	}

