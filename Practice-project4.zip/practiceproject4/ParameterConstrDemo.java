package practiceproject4;
//parameterized constructor 
 class ParameterConstrDemo1 {  	
	ParameterConstrDemo1(double salary,double bonus) {
		double finalamount=bonus+salary;
		System.out.println("final salary is   "+finalamount);
	}

}


public class ParameterConstrDemo {

	public static void main(String[] args) {
		ParameterConstrDemo1 ParameterConstrDemo1=new ParameterConstrDemo1(50000,4000);
		
	}

}
