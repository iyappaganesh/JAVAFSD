package practiceproject4;
//default constructor 
class ConstructorDemoproj1 {  	
	ConstructorDemoproj1() {
		double salary=50000;
		double bonus=48000;
		double finalamount=bonus+salary;
		System.out.println("final salary "+finalamount);
	}

}


public class ConstructorDemoproj {

	public static void main(String[] args) {
		ConstructorDemoproj1 ConstructorDemoproj1=new ConstructorDemoproj1();
		
	}

}



