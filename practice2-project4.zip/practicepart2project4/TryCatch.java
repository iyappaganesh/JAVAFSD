package practicepart2project4;

public class TryCatch {
	public static void main(String[] args) {
		try {
		int a=12/0;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("this prints even after error");
	}

}
