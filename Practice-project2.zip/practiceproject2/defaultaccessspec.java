package practiceproject2;
class defAccessSpecifier
{ 
  void display() 
     { 
         System.out.println("default access specifier"); 
     } 
} 

public class defaultaccessspec {

	public static void main(String[] args) {
		System.out.println("Default Access Specifier both are printed ");
		defAccessSpecifier obj = new defAccessSpecifier(); 		  
        obj.display(); 

	}
}


