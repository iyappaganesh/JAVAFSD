package pack1;

public class ProaccessSpecifiers {
	protected void display() 
    { 
        System.out.println("protected access specifier"); 
    } 


}
