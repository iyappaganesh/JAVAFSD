package pack1;

public class PubaccessSpecifiers {

	public void display() 
    { 
        System.out.println("Public Access Specifiers"); 
    } 
}
